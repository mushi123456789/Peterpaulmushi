"""
Python Security Detection & Alerting
------------------------------------
A lightweight defensive file-monitoring tool for a cybersecurity portfolio.

The detector scans a configured directory at a fixed interval, identifies
files with configured suspicious extensions, prints timestamped alerts, and
records events in a log file.

This is a portfolio/demo tool, not a replacement for endpoint security software.
"""

import logging
import os
import time
from datetime import datetime
from pathlib import Path

# =========================
# Configuration
# =========================
MONITOR_FOLDER = Path(os.environ.get("SECURITY_MONITOR_FOLDER", r"D:\Pictures"))
LOG_FILE = Path(os.environ.get("SECURITY_LOG_FILE", "security_alert.log"))
SCAN_INTERVAL_SECONDS = 5

SUSPICIOUS_EXTENSIONS = {
    ".exe", ".bat", ".vbs", ".ps1", ".zip",
    ".7z", ".rar", ".py", ".html", ".db"
}

# =========================
# Logging
# =========================
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)

detected_files = set()


def print_banner() -> None:
    print("=" * 50)
    print("        PYTHON SECURITY DETECTOR")
    print("=" * 50)
    print(f"Monitoring : {MONITOR_FOLDER}")
    print(f"Log file   : {LOG_FILE.resolve()}")
    print(f"Interval   : {SCAN_INTERVAL_SECONDS} seconds")
    print("Status     : Waiting for suspicious files...\n")


def generate_alert(filepath: Path) -> None:
    current_time = datetime.now()
    date = current_time.strftime("%Y-%m-%d")
    clock = current_time.strftime("%H:%M:%S")
    extension = filepath.suffix.lower()

    print("\n🚨 SECURITY ALERT 🚨")
    print(f"Date          : {date}")
    print(f"Time          : {clock}")
    print(f"Suspicious file: {filepath.name}")
    print(f"File type     : {extension}")
    print(f"Location      : {filepath}")
    print("-" * 50)

    logging.warning(
        "SECURITY ALERT | Date=%s | Time=%s | File=%s | Type=%s | Location=%s",
        date,
        clock,
        filepath.name,
        extension,
        filepath,
    )


def scan_folder() -> None:
    """Scan the configured directory and generate alerts for new matches."""
    if not MONITOR_FOLDER.exists():
        print(f"WARNING: Folder does not exist: {MONITOR_FOLDER}")
        logging.warning("Monitoring folder does not exist: %s", MONITOR_FOLDER)
        return

    if not MONITOR_FOLDER.is_dir():
        print(f"WARNING: Monitoring path is not a directory: {MONITOR_FOLDER}")
        logging.warning("Monitoring path is not a directory: %s", MONITOR_FOLDER)
        return

    try:
        for entry in MONITOR_FOLDER.iterdir():
            if not entry.is_file():
                continue

            extension = entry.suffix.lower()

            if extension in SUSPICIOUS_EXTENSIONS:
                normalized_path = str(entry.resolve())

                if normalized_path not in detected_files:
                    generate_alert(entry)
                    detected_files.add(normalized_path)

    except PermissionError as exc:
        print(f"ERROR: Permission denied: {exc}")
        logging.error("Permission denied while scanning %s: %s", MONITOR_FOLDER, exc)
    except OSError as exc:
        print(f"ERROR: File-system error: {exc}")
        logging.error("File-system error while scanning %s: %s", MONITOR_FOLDER, exc)


def main() -> None:
    print_banner()

    try:
        while True:
            scan_folder()
            time.sleep(SCAN_INTERVAL_SECONDS)

    except KeyboardInterrupt:
        print("\nSecurity monitor stopped.")
        logging.info("Security monitor stopped by user.")


if __name__ == "__main__":
    main()
