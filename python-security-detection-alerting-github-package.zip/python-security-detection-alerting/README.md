# Python Security Detection & Alerting

A lightweight Python defensive-security project that monitors a directory for configured suspicious file extensions, generates timestamped security alerts, and records detection events in a log file.

> **Portfolio project:** This project demonstrates practical Python, file-system monitoring, security-event detection, logging, and basic alerting skills.

## Project Objectives

- Monitor a selected directory.
- Identify files matching configured suspicious extensions.
- Generate a visible security alert.
- Record the alert with date, time, file name, type, and location.
- Avoid repeatedly alerting on the same detected file during one execution.
- Handle missing folders, permission errors, and file-system errors.

## Architecture

```text
                  +----------------------+
                  | Configured Directory |
                  +----------+-----------+
                             |
                             v
                    +----------------+
                    | Folder Scanner |
                    +-------+--------+
                            |
                            v
                 +----------------------+
                 | Check File Extension |
                 +----------+-----------+
                            |
                   Suspicious match?
                      /           \
                    No             Yes
                    |               |
                    v               v
                 Ignore       +-------------+
                              | Alert Engine |
                              +------+------+ 
                                     |
                         +-----------+-----------+
                         |                       |
                         v                       v
                  Terminal Alert          security_alert.log
```

## Technology Stack

- Python 3
- Python standard library
- `pathlib`
- `os`
- `datetime`
- `logging`
- `time`

No third-party Python packages are required.

## Project Structure

```text
python-security-detection-alerting/
├── README.md
├── security_detector.py
├── security_alert.log
├── requirements.txt
├── .gitignore
├── LICENSE
├── screenshots/
│   ├── 01-program-running.png
│   ├── 02-suspicious-file-detected.png
│   ├── 03-security-alert.png
│   ├── 04-security-log.png
│   └── 05-github-repository.png
└── docs/
    └── project-report.md
```

## Setup

### 1. Install Python

Verify Python:

```powershell
python --version
```

### 2. Clone the repository

```powershell
git clone https://github.com/YOUR-USERNAME/python-security-detection-alerting.git
cd python-security-detection-alerting
```

### 3. Configure the monitoring folder

The default folder is:

```text
D:\Pictures
```

You can change it without editing the code by setting an environment variable.

PowerShell example:

```powershell
$env:SECURITY_MONITOR_FOLDER="C:\Monitoring"
python security_detector.py
```

Optional log-file configuration:

```powershell
$env:SECURITY_LOG_FILE="security_alert.log"
python security_detector.py
```

## Running the Detector

```powershell
python security_detector.py
```

Expected startup output:

```text
==================================================
        PYTHON SECURITY DETECTOR
==================================================
Monitoring : D:\Pictures
Log file   : ...\security_alert.log
Interval   : 5 seconds
Status     : Waiting for suspicious files...
```

## Safe Testing Procedure

For portfolio testing, use a dedicated test folder rather than sensitive system directories.

Example:

```powershell
mkdir C:\Monitoring
$env:SECURITY_MONITOR_FOLDER="C:\Monitoring"
python security_detector.py
```

In a second PowerShell window, create a harmless test file:

```powershell
New-Item C:\Monitoring\portfolio-test.py -ItemType File
```

The detector should identify the `.py` extension and generate an alert.

**Important:** The detector checks file extensions. It does not determine whether a file is actually malicious.

## Example Alert

```text
🚨 SECURITY ALERT 🚨
Date           : 2026-09-16
Time           : 14:00:00
Suspicious file: portfolio-test.py
File type      : .py
Location       : C:\Monitoring\portfolio-test.py
--------------------------------------------------
```

## Example Log Entry

```text
2026-09-16 14:00:00 | WARNING | SECURITY ALERT | Date=2026-09-16 | Time=14:00:00 | File=portfolio-test.py | Type=.py | Location=C:\Monitoring\portfolio-test.py
```

## Detection Logic

The project maintains a configurable list of extensions:

```python
SUSPICIOUS_EXTENSIONS = {
    ".exe", ".bat", ".vbs", ".ps1", ".zip",
    ".7z", ".rar", ".py", ".html", ".db"
}
```

When a file matches one of these extensions, the program generates an alert and logs the event.

## Security Considerations

This is an educational/portfolio detector and should not be described as antivirus or malware detection.

Limitations:

- Extension-based detection can produce false positives.
- A malicious file can use a different extension.
- The current implementation scans periodically rather than using real-time OS file-system events.
- It does not calculate file hashes.
- It does not perform malware analysis.
- It does not automatically quarantine files.

## Future Improvements

Planned enhancements include:

1. SHA-256 file hashing.
2. Recursive directory monitoring.
3. CSV/JSON structured event output.
4. Windows Event Log integration.
5. Email or webhook alerting.
6. Wazuh integration.
7. Suricata/Wazuh correlation.
8. Configuration through a YAML/JSON file.
9. Unit tests.
10. Dashboard visualization.

## Portfolio Evidence

Five recommended screenshots are included in the project evidence plan:

1. Program running.
2. Test file detected.
3. Security alert displayed.
4. Alert log generated.
5. GitHub repository structure.

## Author

**Peter Paul Mushi**

Cybersecurity with Artificial Intelligence | Python | SOC Monitoring | Security Detection & Alerting
