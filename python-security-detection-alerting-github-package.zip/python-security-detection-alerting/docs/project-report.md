# Project Report — Python Security Detection & Alerting

## 1. Project Overview

This project implements a lightweight Python security-monitoring detector. It scans a configured directory at regular intervals and identifies files whose extensions are included in a configured suspicious-extension list.

## 2. Problem Statement

Security teams need mechanisms that can identify potentially suspicious activity and preserve evidence for investigation. This project demonstrates a simple file-based detection and alerting workflow suitable for cybersecurity learning and portfolio demonstration.

## 3. Objectives

- Detect configured suspicious file types.
- Generate timestamped alerts.
- Record security events in a log.
- Demonstrate defensive Python programming.
- Produce evidence that can be reviewed by an employer or assessor.

## 4. Detection Workflow

1. Start the Python detector.
2. Select the monitoring directory.
3. Scan the directory every five seconds.
4. Inspect each file extension.
5. Compare the extension with the configured list.
6. Generate an alert for a new match.
7. Record the event in `security_alert.log`.
8. Continue monitoring until stopped.

## 5. Testing

A harmless test file should be created in a dedicated test directory, for example:

`C:\Monitoring\portfolio-test.py`

The expected result is a terminal alert and a corresponding log entry.

## 6. Evidence Checklist

### Screenshot 1 — Program Running
Show the terminal with the detector banner, monitoring path, log path, and waiting status.

### Screenshot 2 — Suspicious File Detected
Show the test file being created or visible in the monitored folder and the detector identifying it.

### Screenshot 3 — Security Alert
Show the alert containing date, time, file name, extension, and location.

### Screenshot 4 — Security Log
Open `security_alert.log` and show the corresponding event.

### Screenshot 5 — GitHub Repository
Show the repository with README, Python source, documentation, and screenshots folder.

## 7. Limitations

The detector is extension-based. A matching extension does not prove that a file is malicious, and a malicious file may use an extension not included in the configuration. The project is therefore an educational detection prototype, not a full endpoint detection and response (EDR) product.

## 8. Future Development

Possible next steps are recursive monitoring, file hashing, structured JSON/CSV events, Windows Event Log integration, Wazuh integration, alert webhooks, automated testing, and dashboard visualization.

## 9. Skills Demonstrated

- Python programming
- Defensive security monitoring
- File-system analysis
- Security event logging
- Alert generation
- Error handling
- Documentation
- Git/GitHub project management
- Security evidence collection
